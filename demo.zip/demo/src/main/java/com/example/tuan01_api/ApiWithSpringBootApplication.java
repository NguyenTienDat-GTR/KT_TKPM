package com.example.tuan01_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiWithSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiWithSpringBootApplication.class, args);
	}

}
